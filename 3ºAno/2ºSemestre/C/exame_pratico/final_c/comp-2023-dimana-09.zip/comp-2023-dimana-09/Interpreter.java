@SuppressWarnings("CheckReturnValue")
public class Interpreter extends DimensionalLanguageBaseVisitor<String> {

   @Override
   public String visitProgram(DimensionalLanguageParser.ProgramContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitStat(DimensionalLanguageParser.StatContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitFor_loop(DimensionalLanguageParser.For_loopContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitNormal_expressions(DimensionalLanguageParser.Normal_expressionsContext ctx) {
      // System.out.println("ola");
      // String res = (ctx.toString());
      // System.out.println("visitNormal_expressions: "+res);
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitIn_loop_expressions(DimensionalLanguageParser.In_loop_expressionsContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitOut_loop_expressions(DimensionalLanguageParser.Out_loop_expressionsContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitCreate_dimension(DimensionalLanguageParser.Create_dimensionContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitUse_import(DimensionalLanguageParser.Use_importContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitCreate_variable(DimensionalLanguageParser.Create_variableContext ctx) {
      String res = null;
      if (ctx.create_normal_variable() != null) {
         // Process normal variable creation
         visit(ctx.create_normal_variable());
         System.out.println(ctx.create_normal_variable().TEXT());

      } else if (ctx.create_dim_variable() != null) {
         // Process dimensional variable creation
         visit(ctx.create_dim_variable());
         System.out.println(ctx.create_dim_variable().TEXT());

      } else if (ctx.create_str_variable() != null) {
         // Process string variable creation
         visit(ctx.create_str_variable());
         System.out.println(ctx.create_str_variable().TEXT());
      }
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitAssignment(DimensionalLanguageParser.AssignmentContext ctx) {
      String res = null;

      if (ctx.normal_ass() != null) {
         // Process normal variable creation
         visit(ctx.normal_ass());
         System.out.println(ctx.normal_ass().getText());
      } else if (ctx.dim_ass() != null) {
         // Process dimensional variable creation
         visit(ctx.dim_ass());
         System.out.println(ctx.dim_ass().getText());
      } else if (ctx.unit_ass() != null) {
         // Process string variable creation
         visit(ctx.unit_ass());
         System.out.println(ctx.unit_ass().getText());
      }
      else if (ctx.add_to_list() != null) {
         // Process string variable creation
         visit(ctx.add_to_list());
         System.out.println(ctx.add_to_list().getText());
      }
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitPrint(DimensionalLanguageParser.PrintContext ctx) {
      String res = visit(ctx.string_to_print());
      if (res != null)
         System.out.println(res);
      return res;
   }

   @Override
   public String visitInit_for(DimensionalLanguageParser.Init_forContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitEnd_for(DimensionalLanguageParser.End_forContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitCreate_normal_variable(DimensionalLanguageParser.Create_normal_variableContext ctx) {
      String res = ctx.getText();
      // System.out.println((res));
      System.out.println("onde tas: " + res);
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitCreate_dim_variable(DimensionalLanguageParser.Create_dim_variableContext ctx) {
      String res = ctx.getText();
      // System.out.println((res));
      // return visitChildren(ctx);
      return res;
   }

   @Override
   public String visitCreate_str_variable(DimensionalLanguageParser.Create_str_variableContext ctx) {
      String res = ctx.getText();
      return null;
      // return res;
   }

   @Override
   public String visitCreate_list(DimensionalLanguageParser.Create_listContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitAdd_to_list(DimensionalLanguageParser.Add_to_listContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitUnit_ass(DimensionalLanguageParser.Unit_assContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitNormal_ass(DimensionalLanguageParser.Normal_assContext ctx) {
      String res = visit(ctx.expr());
      // System.out.println(("cona: " + res));
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitDim_ass(DimensionalLanguageParser.Dim_assContext ctx) {
      String res = visit(ctx.expr());
      // System.out.println("res:" + res);
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitInd_type(DimensionalLanguageParser.Ind_typeContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitDep_type(DimensionalLanguageParser.Dep_typeContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitType(DimensionalLanguageParser.TypeContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitList_types(DimensionalLanguageParser.List_typesContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitWrite(DimensionalLanguageParser.WriteContext ctx) {
      String res = null;
      System.out.println("writeee");
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitWriteln(DimensionalLanguageParser.WritelnContext ctx) {
      String res = null;
      System.out.println("writelnnn");
      return visitChildren(ctx);

      // return res;
   }

   @Override
   public String visitString_to_print(DimensionalLanguageParser.String_to_printContext ctx) {
      for (int i = 0; i <= 2; i++) {
         if (ctx.personalized_string(i) != null) {
            String types = visit(ctx.personalized_string(i).write_string_type());
            System.out.println("Type: " + types + "\tLength: " + ctx.personalized_string(i).INTEGER());
         }
      }
      return null;
   }

   @Override
   public String visitPersonalized_string(DimensionalLanguageParser.Personalized_stringContext ctx) {
      // String res = visit(ctx.write_string_type());
      return null;
      // return res;
   }

   @Override
   public String visitWrite_string_type(DimensionalLanguageParser.Write_string_typeContext ctx) {
      String res = ctx.getText(); // NMEC, Name, Grade e n
      return res;
      // return res;
   }

   @Override
   public String visitExpression_to_add(DimensionalLanguageParser.Expression_to_addContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitIntegers(DimensionalLanguageParser.IntegersContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitExpression_dimension(DimensionalLanguageParser.Expression_dimensionContext ctx) {
      String res = null;
      return visitChildren(ctx);
      // return res;
   }

   @Override
   public String visitExpr(DimensionalLanguageParser.ExprContext ctx) {
      // String res = ctx.getText();
      // System.out.println("cona: " + res);
      return visitChildren(ctx);
      // return res;
   }
}
