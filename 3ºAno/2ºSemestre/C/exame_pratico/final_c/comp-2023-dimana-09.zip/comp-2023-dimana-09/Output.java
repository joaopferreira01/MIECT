import java.util.*;
import java.io.*;

public class Output {
	public static void main(String[] args) {
null	}
}
