// Generated from DimensionalLanguage.g4 by ANTLR 4.12.0
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DimensionalLanguageParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DimensionalLanguageVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(DimensionalLanguageParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStat(DimensionalLanguageParser.StatContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#for_loop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_loop(DimensionalLanguageParser.For_loopContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#normal_expressions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNormal_expressions(DimensionalLanguageParser.Normal_expressionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#in_loop_expressions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn_loop_expressions(DimensionalLanguageParser.In_loop_expressionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#out_loop_expressions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOut_loop_expressions(DimensionalLanguageParser.Out_loop_expressionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#create_dimension}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_dimension(DimensionalLanguageParser.Create_dimensionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#use_import}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_import(DimensionalLanguageParser.Use_importContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#create_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_variable(DimensionalLanguageParser.Create_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment(DimensionalLanguageParser.AssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#print}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrint(DimensionalLanguageParser.PrintContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#init_for}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInit_for(DimensionalLanguageParser.Init_forContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#end_for}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnd_for(DimensionalLanguageParser.End_forContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#create_normal_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_normal_variable(DimensionalLanguageParser.Create_normal_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#create_dim_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_dim_variable(DimensionalLanguageParser.Create_dim_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#create_str_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_str_variable(DimensionalLanguageParser.Create_str_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#create_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_list(DimensionalLanguageParser.Create_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#add_to_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_to_list(DimensionalLanguageParser.Add_to_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#unit_ass}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnit_ass(DimensionalLanguageParser.Unit_assContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#normal_ass}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNormal_ass(DimensionalLanguageParser.Normal_assContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#dim_ass}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDim_ass(DimensionalLanguageParser.Dim_assContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#ind_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInd_type(DimensionalLanguageParser.Ind_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#dep_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDep_type(DimensionalLanguageParser.Dep_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(DimensionalLanguageParser.TypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#list_types}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList_types(DimensionalLanguageParser.List_typesContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#write}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite(DimensionalLanguageParser.WriteContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#writeln}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWriteln(DimensionalLanguageParser.WritelnContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#string_to_print}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString_to_print(DimensionalLanguageParser.String_to_printContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#personalized_string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPersonalized_string(DimensionalLanguageParser.Personalized_stringContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#write_string_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_string_type(DimensionalLanguageParser.Write_string_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#expression_to_add}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression_to_add(DimensionalLanguageParser.Expression_to_addContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#integers}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntegers(DimensionalLanguageParser.IntegersContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#expression_dimension}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression_dimension(DimensionalLanguageParser.Expression_dimensionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionalLanguageParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr(DimensionalLanguageParser.ExprContext ctx);
}