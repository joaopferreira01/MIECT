import org.stringtemplate.v4.*;
import java.util.*;

@SuppressWarnings("CheckReturnValue")
public class Interpreter extends DimensionalLanguageBaseVisitor<ST> {

   private STGroup templates = new STGroupFile("java.stg");

   @Override public ST visitProgram(DimensionalLanguageParser.ProgramContext ctx) {
      
      ST res = templates.getInstanceOf("module");
      res.add("name","test");
		Iterator<DimensionalLanguageParser.StatContext> list = ctx.stat().iterator();
      while(list.hasNext()) {
         res.add("stat", visit(list.next()).render());
      }
      
      return res;
      
      // ST top = templates.getInstanceOf("module");
      // System.out.print("OLA: " + top.render());   
      // String a = visit(ctx.stat(0));   
      // System.out.println(a);
      // return visitChildren(ctx);
      // //return res;
   }

   @Override public ST visitStat(DimensionalLanguageParser.StatContext ctx) {
      System.out.println("CONINHA BOUA");
      ST res = templates.getInstanceOf("stats");
      res.add("stat", visit(ctx.normal_expressions()).render());
		// Iterator<DimensionalLanguageParser.StatContext> list = ctx.normal_expressions();
      return res;
      // return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitFor_loop(DimensionalLanguageParser.For_loopContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitNormal_expressions(DimensionalLanguageParser.Normal_expressionsContext ctx) {
      System.out.println("CONINHA Muito BOUA2");
      ST res = null;
      return res;
      //return res;
   }

   @Override public ST visitIn_loop_expressions(DimensionalLanguageParser.In_loop_expressionsContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitOut_loop_expressions(DimensionalLanguageParser.Out_loop_expressionsContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitCreate_dimension(DimensionalLanguageParser.Create_dimensionContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitUse_import(DimensionalLanguageParser.Use_importContext ctx) {
      ST res = templates.getInstanceOf("print");
         res.add("value","test");
      return res;
      // return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitCreate_variable(DimensionalLanguageParser.Create_variableContext ctx) {
      // ST res = null;
      // ST top = templates.getInstanceOf("module");
      // System.out.print("OLA: " + top.render());   
      // String a = visit(ctx.create_dim_variable());   
      // System.out.println(a);
      // return visitChildren(ctx);
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitAssignment(DimensionalLanguageParser.AssignmentContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitPrint(DimensionalLanguageParser.PrintContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitInit_for(DimensionalLanguageParser.Init_forContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitEnd_for(DimensionalLanguageParser.End_forContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitCreate_normal_variable(DimensionalLanguageParser.Create_normal_variableContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitCreate_dim_variable(DimensionalLanguageParser.Create_dim_variableContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitCreate_str_variable(DimensionalLanguageParser.Create_str_variableContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitCreate_list(DimensionalLanguageParser.Create_listContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitAdd_to_list(DimensionalLanguageParser.Add_to_listContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitUnit_ass(DimensionalLanguageParser.Unit_assContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitNormal_ass(DimensionalLanguageParser.Normal_assContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitDim_ass(DimensionalLanguageParser.Dim_assContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitInd_type(DimensionalLanguageParser.Ind_typeContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitDep_type(DimensionalLanguageParser.Dep_typeContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitType(DimensionalLanguageParser.TypeContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitList_types(DimensionalLanguageParser.List_typesContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitWrite(DimensionalLanguageParser.WriteContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitWriteln(DimensionalLanguageParser.WritelnContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitString_to_print(DimensionalLanguageParser.String_to_printContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitPersonalized_string(DimensionalLanguageParser.Personalized_stringContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitWrite_string_type(DimensionalLanguageParser.Write_string_typeContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitExpression_to_add(DimensionalLanguageParser.Expression_to_addContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitIntegers(DimensionalLanguageParser.IntegersContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitExpression_dimension(DimensionalLanguageParser.Expression_dimensionContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitExpr(DimensionalLanguageParser.ExprContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }
}
