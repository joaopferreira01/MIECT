public class Dimension {
    private String dimensionName;
    private String dimensionType;
    private String baseUnit;

    public Dimension(String dimensionName, String dimensionType, String baseUnit) {
        this.dimensionName = dimensionName;
        this.dimensionType = dimensionType;
        this.baseUnit = baseUnit;
    }

    // Getters and setters for the class variables

    public String getDimensionName() {
        return dimensionName;
    }

    public void setDimensionName(String dimensionName) {
        this.dimensionName = dimensionName;
    }

    public String getDimensionType() {
        return dimensionType;
    }

    public void setDimensionType(String dimensionType) {
        this.dimensionType = dimensionType;
    }

    public String getBaseUnit() {
        return baseUnit;
    }

    public void setBaseUnit(String baseUnit) {
        this.baseUnit = baseUnit;
    }

    // Other methods, if needed

    @Override
    public String toString() {
        return "Dimension [dimensionName=" + dimensionName + ", dimensionType=" + dimensionType + ", baseUnit=" + baseUnit + "]";
    }
}
