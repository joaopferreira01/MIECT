// Generated from DimensionalLanguage.g4 by ANTLR 4.12.0
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DimensionalLanguageParser}.
 */
public interface DimensionalLanguageListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(DimensionalLanguageParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(DimensionalLanguageParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterStat(DimensionalLanguageParser.StatContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitStat(DimensionalLanguageParser.StatContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#for_loop}.
	 * @param ctx the parse tree
	 */
	void enterFor_loop(DimensionalLanguageParser.For_loopContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#for_loop}.
	 * @param ctx the parse tree
	 */
	void exitFor_loop(DimensionalLanguageParser.For_loopContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#normal_expressions}.
	 * @param ctx the parse tree
	 */
	void enterNormal_expressions(DimensionalLanguageParser.Normal_expressionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#normal_expressions}.
	 * @param ctx the parse tree
	 */
	void exitNormal_expressions(DimensionalLanguageParser.Normal_expressionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#in_loop_expressions}.
	 * @param ctx the parse tree
	 */
	void enterIn_loop_expressions(DimensionalLanguageParser.In_loop_expressionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#in_loop_expressions}.
	 * @param ctx the parse tree
	 */
	void exitIn_loop_expressions(DimensionalLanguageParser.In_loop_expressionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#out_loop_expressions}.
	 * @param ctx the parse tree
	 */
	void enterOut_loop_expressions(DimensionalLanguageParser.Out_loop_expressionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#out_loop_expressions}.
	 * @param ctx the parse tree
	 */
	void exitOut_loop_expressions(DimensionalLanguageParser.Out_loop_expressionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#create_dimension}.
	 * @param ctx the parse tree
	 */
	void enterCreate_dimension(DimensionalLanguageParser.Create_dimensionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#create_dimension}.
	 * @param ctx the parse tree
	 */
	void exitCreate_dimension(DimensionalLanguageParser.Create_dimensionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#use_import}.
	 * @param ctx the parse tree
	 */
	void enterUse_import(DimensionalLanguageParser.Use_importContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#use_import}.
	 * @param ctx the parse tree
	 */
	void exitUse_import(DimensionalLanguageParser.Use_importContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#create_variable}.
	 * @param ctx the parse tree
	 */
	void enterCreate_variable(DimensionalLanguageParser.Create_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#create_variable}.
	 * @param ctx the parse tree
	 */
	void exitCreate_variable(DimensionalLanguageParser.Create_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(DimensionalLanguageParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(DimensionalLanguageParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#print}.
	 * @param ctx the parse tree
	 */
	void enterPrint(DimensionalLanguageParser.PrintContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#print}.
	 * @param ctx the parse tree
	 */
	void exitPrint(DimensionalLanguageParser.PrintContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#init_for}.
	 * @param ctx the parse tree
	 */
	void enterInit_for(DimensionalLanguageParser.Init_forContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#init_for}.
	 * @param ctx the parse tree
	 */
	void exitInit_for(DimensionalLanguageParser.Init_forContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#end_for}.
	 * @param ctx the parse tree
	 */
	void enterEnd_for(DimensionalLanguageParser.End_forContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#end_for}.
	 * @param ctx the parse tree
	 */
	void exitEnd_for(DimensionalLanguageParser.End_forContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#create_normal_variable}.
	 * @param ctx the parse tree
	 */
	void enterCreate_normal_variable(DimensionalLanguageParser.Create_normal_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#create_normal_variable}.
	 * @param ctx the parse tree
	 */
	void exitCreate_normal_variable(DimensionalLanguageParser.Create_normal_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#create_dim_variable}.
	 * @param ctx the parse tree
	 */
	void enterCreate_dim_variable(DimensionalLanguageParser.Create_dim_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#create_dim_variable}.
	 * @param ctx the parse tree
	 */
	void exitCreate_dim_variable(DimensionalLanguageParser.Create_dim_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#create_str_variable}.
	 * @param ctx the parse tree
	 */
	void enterCreate_str_variable(DimensionalLanguageParser.Create_str_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#create_str_variable}.
	 * @param ctx the parse tree
	 */
	void exitCreate_str_variable(DimensionalLanguageParser.Create_str_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#create_list}.
	 * @param ctx the parse tree
	 */
	void enterCreate_list(DimensionalLanguageParser.Create_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#create_list}.
	 * @param ctx the parse tree
	 */
	void exitCreate_list(DimensionalLanguageParser.Create_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#add_to_list}.
	 * @param ctx the parse tree
	 */
	void enterAdd_to_list(DimensionalLanguageParser.Add_to_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#add_to_list}.
	 * @param ctx the parse tree
	 */
	void exitAdd_to_list(DimensionalLanguageParser.Add_to_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#unit_ass}.
	 * @param ctx the parse tree
	 */
	void enterUnit_ass(DimensionalLanguageParser.Unit_assContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#unit_ass}.
	 * @param ctx the parse tree
	 */
	void exitUnit_ass(DimensionalLanguageParser.Unit_assContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#normal_ass}.
	 * @param ctx the parse tree
	 */
	void enterNormal_ass(DimensionalLanguageParser.Normal_assContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#normal_ass}.
	 * @param ctx the parse tree
	 */
	void exitNormal_ass(DimensionalLanguageParser.Normal_assContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#dim_ass}.
	 * @param ctx the parse tree
	 */
	void enterDim_ass(DimensionalLanguageParser.Dim_assContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#dim_ass}.
	 * @param ctx the parse tree
	 */
	void exitDim_ass(DimensionalLanguageParser.Dim_assContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#ind_type}.
	 * @param ctx the parse tree
	 */
	void enterInd_type(DimensionalLanguageParser.Ind_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#ind_type}.
	 * @param ctx the parse tree
	 */
	void exitInd_type(DimensionalLanguageParser.Ind_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#dep_type}.
	 * @param ctx the parse tree
	 */
	void enterDep_type(DimensionalLanguageParser.Dep_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#dep_type}.
	 * @param ctx the parse tree
	 */
	void exitDep_type(DimensionalLanguageParser.Dep_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(DimensionalLanguageParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(DimensionalLanguageParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#list_types}.
	 * @param ctx the parse tree
	 */
	void enterList_types(DimensionalLanguageParser.List_typesContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#list_types}.
	 * @param ctx the parse tree
	 */
	void exitList_types(DimensionalLanguageParser.List_typesContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#write}.
	 * @param ctx the parse tree
	 */
	void enterWrite(DimensionalLanguageParser.WriteContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#write}.
	 * @param ctx the parse tree
	 */
	void exitWrite(DimensionalLanguageParser.WriteContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#writeln}.
	 * @param ctx the parse tree
	 */
	void enterWriteln(DimensionalLanguageParser.WritelnContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#writeln}.
	 * @param ctx the parse tree
	 */
	void exitWriteln(DimensionalLanguageParser.WritelnContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#string_to_print}.
	 * @param ctx the parse tree
	 */
	void enterString_to_print(DimensionalLanguageParser.String_to_printContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#string_to_print}.
	 * @param ctx the parse tree
	 */
	void exitString_to_print(DimensionalLanguageParser.String_to_printContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#personalized_string}.
	 * @param ctx the parse tree
	 */
	void enterPersonalized_string(DimensionalLanguageParser.Personalized_stringContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#personalized_string}.
	 * @param ctx the parse tree
	 */
	void exitPersonalized_string(DimensionalLanguageParser.Personalized_stringContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#write_string_type}.
	 * @param ctx the parse tree
	 */
	void enterWrite_string_type(DimensionalLanguageParser.Write_string_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#write_string_type}.
	 * @param ctx the parse tree
	 */
	void exitWrite_string_type(DimensionalLanguageParser.Write_string_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#expression_to_add}.
	 * @param ctx the parse tree
	 */
	void enterExpression_to_add(DimensionalLanguageParser.Expression_to_addContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#expression_to_add}.
	 * @param ctx the parse tree
	 */
	void exitExpression_to_add(DimensionalLanguageParser.Expression_to_addContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#integers}.
	 * @param ctx the parse tree
	 */
	void enterIntegers(DimensionalLanguageParser.IntegersContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#integers}.
	 * @param ctx the parse tree
	 */
	void exitIntegers(DimensionalLanguageParser.IntegersContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#expression_dimension}.
	 * @param ctx the parse tree
	 */
	void enterExpression_dimension(DimensionalLanguageParser.Expression_dimensionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#expression_dimension}.
	 * @param ctx the parse tree
	 */
	void exitExpression_dimension(DimensionalLanguageParser.Expression_dimensionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionalLanguageParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(DimensionalLanguageParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionalLanguageParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(DimensionalLanguageParser.ExprContext ctx);
}