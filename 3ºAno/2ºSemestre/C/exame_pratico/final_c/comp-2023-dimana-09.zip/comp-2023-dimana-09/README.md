# Tema **DimAna**, grupo **dimana-09**
-----

## Constituição dos grupos e participação individual global

| NMec | Nome | email | Participação |
|:---:|:---|:---|:---:|
| 103270 | GABRIEL DUARTE COUTO | gabrielcouto@ua.pt | 0.0% |
| 103185 | GUILHERME DUARTE ALVES | guilherme.alves@ua.pt | 0.0% |
| 103625 | JOÃO PEDRO RAPOSO FERREIRA | joaop.ferreira@ua.pt | 0.0% |
| 103199 | RAFAEL LUÍS FERREIRA CURADO | rafael.curado@ua.pt | 0.0% |
| 104092 | SIMÃO MORENO ANTUNES | simaoma@ua.pt | 0.0% |

## Estrutura do repositório

- **src** - deve conter todo o código fonte do projeto.

- **doc** -- deve conter toda a documentação adicional a este README.

- **examples** -- deve conter os exemplos ilustrativos das linguagens criadas.

    - Estes exemplos devem conter comentários (no formato aceite pelas linguagens),
      que os tornem auto-explicativos.

## Relatório

- Use esta secção para fazer um relatório sucinto mas explicativo dos objetivos concretizados.

## Contribuições

- Use esta secção para expôr as contribuições individuais dos vários elementos do grupo e que
  justificam as participações individuais globais apresentadas no início.
