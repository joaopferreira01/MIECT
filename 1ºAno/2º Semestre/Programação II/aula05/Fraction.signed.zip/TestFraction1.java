import static java.lang.System.*;
import java.util.Arrays;

public class TestFraction1 {
   
   public static void main(String[] args) {
      
      Fraction[] fractions = {
         new Fraction(0, 1),
         new Fraction(1, 1),
         new Fraction(-2, -1),
         new Fraction(6, 3),
         new Fraction(721, -17),
         new Fraction(61, 5),
      };

      out.println("Testing...");
      for (Fraction f: fractions) {
         out.printf("f: %s  f.num(): %d  f.den(): %d\n", f, f.num(), f.den());
      }

      // PODE comentar algumas partes para fazer testes PARCIAIS!

      out.println("Testing equals...");
      for (Fraction f1: fractions) {
         for (Fraction f2: fractions) {
            try {
               out.printf("(%s) equals (%s): ", f1, f2);
               boolean eq = f1.equals(f2);
               out.printf("%b\n", eq);
            } catch (Throwable e) {
               out.printf("Caught: %s\n", e.getMessage());
            }
         }
      }

      out.println("Testing divide...");
      for (Fraction f1: fractions) {
         for (Fraction f2: fractions) {
            try {
               out.printf("(%s) divide (%s): ", f1, f2);
               Fraction f3 = f1.divide(f2);
               out.printf("%s\n", f3);
            } catch (Throwable e) {
               out.printf("Caught: %s\n", e.getMessage());
            }
         }
      }

      out.println("Testing ZERO and ONE...");
      // A instrução abaixo deve dar um erro de compilação!
      //Fraction.ZERO = two;   // This should not be possible!
      out.printf("ZERO: %s\n", Fraction.ZERO);
      out.printf("ONE: %s\n", Fraction.ONE);
      
      out.println("Testing parseFraction...");
      String[] strings = {"3/4", "3/-2", "-2/-3", "1/0", "um/2"};
      for (String s: strings) {
         try {
            out.printf("Fraction.parseFraction(\"%s\"): ", s);
            Fraction f3 = Fraction.parseFraction(s);
            out.printf("%s\n", f3);
         } catch (Throwable e) {
            out.printf("Caught: %s\n", e.getMessage());
         }
      }

   }
}